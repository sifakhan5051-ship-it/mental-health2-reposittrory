document.addEventListener("DOMContentLoaded", () => {
 // Retrieve the latest stored data
 const mood = localStorage.getItem("latestMood");
 const reflection = localStorage.getItem("latestReflection");

 const greetingEl = document.getElementById("greeting");
 const summaryEl = document.getElementById("reflection-summary");
 const messageEl = document.getElementById("gratitude-message");

 // --- 1. Handle Case: No Reflection Found ---
 if (!mood || !reflection) {
 greetingEl.textContent = "Hey there 🌻";
 summaryEl.textContent = "Looks like you haven’t written your reflection yet!";
 messageEl.textContent = "Go back, take a pause, and let your heart speak.";
  return;
 }

 // --- 2. Handle Case: Reflection Found ---
 greetingEl.textContent = Hello, beautiful soul 🌼;
 summaryEl.textContent = You reflected about: "${reflection}";

 let gratitudeMsg = "";

 // Use a switch statement for cleaner mood-based messaging
 switch (mood) {
 case "Happy":
 gratitudeMsg = "Keep shining that smile! Your joy is contagious and lights up your world 💛";
 break;
 case "Grateful":
 gratitudeMsg = "You’re growing beautifully in gratitude 🌸 Stay grounded and kind to yourself.";
 break;
 case "Calm":
 gratitudeMsg = "Embrace this peace. It's a reminder of the quiet strength within you 🧘‍♀";
 break;
 case "Tired":
 gratitudeMsg = "Rest isn’t weakness — it’s how you recharge your light. Take a deep breath and be gentle 🌙";
 break;
 case "Anxious":
 gratitudeMsg = "It’s okay to feel overwhelmed. Remember to breathe; you have handled tough moments before 💜";
 break;
 default:
 gratitudeMsg = "Whatever your heart feels, it’s valid. You’re doing just fine 💫 Acknowledge your inner strength.";
 break;
 }

 messageEl.textContent = gratitudeMsg;

 // --- 3. Refresh Button Clears Only Latest Data (Optional, but recommended) ---
 // The original cleared ALL localStorage, which removed past reflections.
 // This version only clears the 'latest' data upon returning to reflection.html.
 document.getElementById("refreshBtn").addEventListener("click", () => {
 // Clear the latest reflection/mood so the next visit to gratitude.html
 // will require a new entry. Past reflections (in the array) remain.
 localStorage.removeItem("latestMood");
 localStorage.removeItem("latestReflection");
 window.location.href = "reflection.html";
 });
});