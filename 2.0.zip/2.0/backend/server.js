// server.js

// Step 1: Import dependencies
const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const cors = require('cors');
const connectDB = require('./db/connection');

// Step 2: Initialize app
const app = express();

// Step 3: Configure environment variables
dotenv.config();

// Step 4: Connect to MongoDB
connectDB();

// Step 5: Middleware
app.use(cors()); // enable cross-origin requests
app.use(express.json()); // parse JSON bodies

// Step 6: Use routes
const userRoutes = require('./routes/userroutes');
app.use('/api/users', userRoutes);

// Step 7: Test route
app.get('/', (req, res) => {
  res.send('MindWave Backend is running successfully 🧠');
});

// Step 8: Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
