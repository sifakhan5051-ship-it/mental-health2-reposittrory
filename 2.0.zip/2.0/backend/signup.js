// signup.js

document.getElementById("signupForm").addEventListener("submit", async function(e) {
  e.preventDefault(); // Prevent the page from reloading

  // 1️⃣ Collect form data
  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  // 2️⃣ Send the data to backend using Fetch API
  try {
    const response = await fetch("http://localhost:5000/api/users/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ name, email, password })
    });

    // 3️⃣ Convert the response to JSON
    const data = await response.json();

    // 4️⃣ Display a message to the user
    document.getElementById("msg").innerText = data.message || "Something went wrong!";
  } 
  catch (error) {
    document.getElementById("msg").innerText = "Error connecting to server.";
    console.error(error);
  }
});
